Oni Sword (Windows)

Run "Oni Sword.exe". Each time it starts it checks for a newer build of the game and downloads
it (about 25 MB) before playing, so you always have the latest. Offline, it plays the copy it has.
The first start needs an internet connection.

Windows may warn that it's from an unknown publisher (the file isn't code-signed): choose
"More info" then "Run anyway".

The game data lives in %APPDATA%\Godot\app_userdata\Oni Sword Launcher (delete that folder to
start fresh); your settings in %APPDATA%\Godot\app_userdata\Oni Sword.